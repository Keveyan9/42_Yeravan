/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fractal.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skeveyan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/16 14:11:07 by skeveyan          #+#    #+#             */
/*   Updated: 2022/12/09 14:40:31 by skeveyan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <mlx.h>
#include "fractal.h"

int key_hook_man(int code, t_struct_mlx_mandelbrot *mand_var)
{
	if(code == 53)
		exit(0);
	else if (code == 126)
		mand_var->ymove = mand_var->ymove - 10;
	else if (code == 125)
		mand_var->ymove = mand_var->ymove + 10;
	else if (code == 123)
		mand_var->xmove = mand_var->xmove - 10;
	else if (code == 124)
		mand_var->xmove = mand_var->xmove + 10;
	else if (code == 257)
		 mand_var->ciqel = mand_var->ciqel - 1;
	 else if (code == 49)
		mand_var->ciqel = mand_var->ciqel + 1;
	else if (code == 83)
		mand_var->gama = mand_var->gama + 5;
	else if (code == 82)
		mand_var->gama = mand_var->gama - 5;
	else if (code == 69)
		mand_var->zoom = mand_var->zoom - 0.1;
	else if (code == 78)
		mand_var->zoom = mand_var->zoom + 0.1;
	mandelbrot(mand_var);
	return(0);
}


int key_maus_man(int code,int x, int y, t_struct_mlx_mandelbrot *mand_var)
{		
	//	mand_var->ymove = mand_var->ymove - 10;
	//	mand_var->ymove = mand_var->ymove + ;
	//	mand_var->xmove = mand_var->xmove - x;
	//	mand_var->xmove = mand_var->xmove + x;
		if (code == 2)
		   	mand_var->ciqel = mand_var->ciqel - 1;
	 	else if (code == 1)
			mand_var->ciqel = mand_var->ciqel + 1;
		else if (code == 3)
		mand_var->gama = mand_var->gama + 5;
	else if (code == 4)
		mand_var->zoom = mand_var->zoom - 0.1;
	else if (code == 5)
		mand_var->zoom = mand_var->zoom + 0.1;
	mandelbrot(mand_var);
	return(0);
}
int clos(t_struct_mlx_mandelbrot *mand_var)
{
	exit(0);
}

int	main(int argc, char **argv)
{
	int xy[2];
	t_struct_mlx_mandelbrot mand_var;

	mand_var.xsize = 1500;
	mand_var.ysize = 1000;
	mand_var.xmove = 0;
	mand_var.ymove = 0;
	mand_var.ciqel = 200;
	mand_var.gama = 100;
	mand_var.zoom = 4;
	if (argc > 1)
	{
		if (!ft_strncmp("Mandelbrot", argv[1], ft_strlen(argv[1])) && !argv[2])
		{
			open_mlx(argv[1], &mand_var);
			mandelbrot(&mand_var);
			mlx_mouse_hook(mand_var.mlx_win, key_maus_man, &mand_var);
			mlx_key_hook(mand_var.mlx_win, key_hook_man, &mand_var);
			mlx_hook(mand_var.mlx_win, 17, 0, clos, &mand_var);
			mlx_loop(mand_var.mlx);
		}
		else if (!ft_strncmp("Julia", argv[1], ft_strlen(argv[1])))
		{
			open_mlx(argv[1], &mand_var);
			if (argv[2] && argv[3])
				julia(&mand_var);
			else if (argv[1])
				julia(&mand_var);
			else
				ft_printf("is not corect julia coefficent");
	
			//mlx_mouse_hook(mand_var.mlx_win, key_maus_man, &mand_var);
			//mlx_key_hook(mand_var.mlx_win, key_hook_man, &mand_var);
			//mlx_hook(mand_var.mlx_win, 17, 0, clos, &mand_var);
			mlx_loop(mand_var.mlx);

		}	
		else
			ft_printf("is not corect input you can input Mandelbrot or Julia\n");
	}
	return (0);
}
