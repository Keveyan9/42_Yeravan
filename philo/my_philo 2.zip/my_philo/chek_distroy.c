/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chek_distroy.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skeveyan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/09 00:14:33 by skeveyan          #+#    #+#             */
/*   Updated: 2023/01/10 20:54:40 by skeveyan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "philo.h"

long long    get_time(void)
{
    struct timeval    t;

    gettimeofday(&t, NULL);
    return ((t.tv_sec * 1000) + (t.tv_usec / 1000));
}

void    ft_usleep(long long tm)
{
    long long    time;

    time = get_time();
    while (get_time() - time <= tm - 1)
        usleep (100);
}
int chek_distroy_eats_moment(philo_parametr *philos)
{
	while(timer() - philos->starteat <= philos->input->eat)
	{
		if(philos->startsleep > 0)
		{
			if(timer()  - philos->startsleep > philos->input->die)
			{
				print_s(" die is ___________-eat",philos);
				philos->input->print_lock = 0;
				pthread_mutex_lock(&(philos->input->m_print_lock));
				usleep(10);
				pthread_mutex_unlock(&(philos->input->m_print_lock));
				return(1);
			}
		}
	}
	return(0);
}

int chek_distroy_sleep_moment(philo_parametr *philos)
{
	while(timer() - philos->startsleep <= philos->input->sleep)
	{
		if(philos->startsleep > 0)
		{
			if(timer()  - philos->startsleep > philos->input->die)
			{
				print_s(" die is ______________sleep",philos);
				philos->input->print_lock = 0;
				pthread_mutex_lock(&(philos->input->m_print_lock));
				usleep(10);
				pthread_mutex_unlock(&(philos->input->m_print_lock));
				return(1);
			}
		}
	}
	return(0);
}
