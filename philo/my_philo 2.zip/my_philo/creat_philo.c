/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   creat_philo.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skeveyan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/29 12:49:02 by skeveyan          #+#    #+#             */
/*   Updated: 2023/01/10 20:54:40 by skeveyan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "philo.h"

unsigned int  timer()
{
	struct timeval get_tim;
	gettimeofday(&get_tim, NULL);
	return((get_tim.tv_usec/1000) + get_tim.tv_sec*1000);
}

void *logic(void *arg)
{
	philo_parametr *philos;
	int siqel;
	
	siqel = 0; 
	philos = arg;
	philos->tred_finish_id = 1;
	philos->start = timer();
	while(philos->input->tred_finish && (philos->input->ok_siqel == -1
			|| philos->input->ok_siqel > siqel++))
	{	
		if(take_forks(philos))
			break;
		philos->starteat= timer();
		print_s("is eating",philos);
ft_usleep(philos->input->eat);
//while(timer()-philos->starteat > philos->input->eat);
		//	usleep(philos->input->eat * 1000);
//		if(chek_distroy_eats_moment(philos))
//		{
//			put_forks(philos);
//			break;
//	}
		put_forks(philos);
		philos->startsleep = timer();
		print_s("is sleeping ",philos);
	//while(timer()-philos->startsleep > philos->input->sleep);
ft_usleep(philos->input->sleep);
//usleep(philos->input->sleep * 1000);
		//		if(chek_distroy_sleep_moment(philos))
//			break;
		philos->startthink = timer();
		print_s("is thinking ",philos);
	}
	if(siqel + 1 == philos->input->ok_siqel)
		philos->tred_finish_id = -1;
	else
		philos->tred_finish_id = 0;
	return(NULL);
}
int creat_philo(philo_parametr *philo_a,t_input_argument *input)
{
	int n;

	n = 0;
	while(n < input->philo)
	{
		philo_a[n].input = input;
		if(pthread_mutex_init(&(input->fork[n]),NULL))
		{
			printf("mutex_error\n");
			return (1);
		}
		n++;
	}
	pthread_mutex_init(&input->m_print_lock,NULL);
	n = 0;
	while(n < input->philo)
	{
		philo_a[n].number = n;
		philo_a[n].startsleep = 0;
		if(n % 2 == 0)
		{
	 		if(pthread_create(&(philo_a[n].thread),NULL,&logic,&philo_a[n]))
			{
				printf("creat_tread_problems");
				return (1);
			}
		usleep(10);
		}

		n++;
	}
	n = 0;
	usleep(100);
	while(n < input->philo)
	{
		if(n % 2 !=0 )
		{
			if(pthread_create(&(philo_a[n].thread),NULL,&logic,&philo_a[n]))
			{
				printf("creat_tread_problems");
				return (1);
			}
		usleep(10);
		}
		n++;
	}
	n = 0;


	while(n < input->philo )
	{
//		chek_distroy_moment(philo_a[n])
		


	//	if(philo_a[n].tred_finish_id == 0)
	//	{
	//		input->print_lock = 0;
	//		input->tred_finish = 0;
	//		break;
	//	}

	//	if(philo_a[n].tred_finish_id == 0)
	//	{
	//		input->print_lock = 0;
	//		input->tred_finish = 0;
	//		break;
	//	}

		// now chek //
	if(philo_a[n].start > 10 )
	{
		if(philo_a[n].startsleep == 0)
		{
			if(timer() - philo_a[n].start > input->die)
				{

				print_s(" die is can not eat",&philo_a[n]);
				input->print_lock = 0;
				pthread_mutex_lock(&input->m_print_lock);
				input->tred_finish = 0;
				usleep(100);
				pthread_mutex_unlock(&input->m_print_lock);
				break;
				}	
		}
		else
		{
			if(timer() - philo_a[n].startsleep > input->die)
				{

				print_s(" die is can not reach  eat",&philo_a[n]);
				input->print_lock = 0;
				pthread_mutex_lock(&input->m_print_lock);
				input->tred_finish = 0;
				usleep(100);
				pthread_mutex_unlock(&input->m_print_lock);
				break;
				}	
		}
	}

		n++;
		if(n == input->philo)
			n = 0;	
	}

	while(n < input->philo)
		pthread_join(philo_a[n++].thread,NULL);
	return(0);
}
